import { createClient } from '@supabase/supabase-js';
import {
  ProposalItem,
  ClientItem,
  FollowUpItem,
  ClientMessageItem,
  ClientWorkspaceTaskItem,
  ProposalStatus,
  ProposalStyleTone,
} from '../data/zendoProposalsData';

const metaEnv = (
  import.meta as unknown as { env?: Record<string, string | undefined> }
).env;

const DEFAULT_SUPABASE_URL = 'https://jsmbnwqbaebxfmhkusth.supabase.co';
const DEFAULT_SUPABASE_PUBLISHABLE_KEY =
  'sb_publishable_yDXTVqFlNO3wQ8yBhI8LWA_bIx7zhT8';

function resolveValidSupabaseUrl(...candidates: (string | undefined)[]): string {
  for (const candidate of candidates) {
    if (!candidate) continue;
    const trimmed = candidate.trim();
    if (/^https?:\/\/.+/i.test(trimmed)) {
      try {
        new URL(trimmed);
        return trimmed;
      } catch {
        // continue to next candidate
      }
    }
  }
  return DEFAULT_SUPABASE_URL;
}

function resolveValidSupabaseKey(...candidates: (string | undefined)[]): string {
  for (const candidate of candidates) {
    if (!candidate) continue;
    const trimmed = candidate.trim();
    // Avoid accidentally using a secret key in the browser client
    if (trimmed.length > 10 && !trimmed.startsWith('sb_secret_')) {
      return trimmed;
    }
  }
  return DEFAULT_SUPABASE_PUBLISHABLE_KEY;
}

export const SUPABASE_URL = resolveValidSupabaseUrl(
  metaEnv?.NEXT_PUBLIC_SUPABASE_URL,
  metaEnv?.VITE_SUPABASE_URL,
  DEFAULT_SUPABASE_URL
);

export const SUPABASE_PUBLISHABLE_KEY = resolveValidSupabaseKey(
  metaEnv?.NEXT_PUBLIC_SUPABASE_PUBLISHABLE_KEY,
  metaEnv?.VITE_SUPABASE_PUBLISHABLE_KEY,
  DEFAULT_SUPABASE_PUBLISHABLE_KEY
);

export const supabase = createClient(SUPABASE_URL, SUPABASE_PUBLISHABLE_KEY, {
  auth: {
    persistSession: true,
    autoRefreshToken: true,
  },
});

interface SupabaseProposalRow {
  id: string;
  title: string;
  client_name: string;
  client_company: string;
  client_email: string;
  industry: string;
  value: string;
  numeric_value: number;
  status: string;
  updated_at_label: string;
  style: string;
  timeline_summary: string;
  services_json: string;
  sections_json: string;
}

interface SupabaseClientRow {
  id: string;
  name: string;
  company: string;
  email: string;
  industry: string;
  total_proposals: number;
  pipeline_value: string;
  last_activity: string;
  status: string;
}

interface SupabaseFollowUpRow {
  id: string;
  proposal_id: string;
  proposal_title: string;
  client_company: string;
  contact_name: string;
  contact_email: string;
  headline: string;
  subtext: string;
  timing_badge: string;
  ai_insight: string;
  suggested_subject: string;
  suggested_message: string;
  sent: boolean;
}

interface SupabaseMessageRow {
  id: string;
  proposal_id: string;
  client_company: string;
  sender_name: string;
  sender_role: string;
  message_text: string;
  time_label: string;
}

interface SupabaseTaskRow {
  id: string;
  client_company: string;
  title: string;
  category: string;
  due_date: string;
  status: string;
  notes: string;
}

function mapRowToProposal(row: SupabaseProposalRow): ProposalItem {
  let parsedServices: string[] = [];
  let parsedSections: ProposalItem['sections'] = {
    coverSubtitle: '',
    preparedFor: '',
    preparedBy: '',
    dateIssued: '',
    validUntil: '',
    executiveSummary: '',
    clientProblem: '',
    proposedSolution: '',
    servicesDeliverables: [],
    timeline: [],
    pricingItems: [],
    pricingNote: '',
    termsAndNextSteps: '',
  };

  try {
    parsedServices = JSON.parse(row.services_json || '[]');
  } catch {
    parsedServices = [];
  }

  try {
    parsedSections = JSON.parse(row.sections_json || '{}');
  } catch {
    // keep default
  }

  return {
    id: row.id,
    title: row.title,
    clientName: row.client_name,
    clientCompany: row.client_company,
    clientEmail: row.client_email,
    industry: row.industry,
    value: row.value,
    numericValue: Number(row.numeric_value) || 0,
    status: (row.status as ProposalStatus) || 'Draft',
    updatedAt: row.updated_at_label || 'Just now',
    style: (row.style as ProposalStyleTone) || 'Premium',
    timelineSummary: row.timeline_summary || '4 weeks',
    services: parsedServices,
    sections: parsedSections,
  };
}

export async function fetchWorkspaceFromSupabase(): Promise<{
  proposals: ProposalItem[];
  clients: ClientItem[];
  followUps: FollowUpItem[];
  clientMessages: ClientMessageItem[];
  clientTasks: ClientWorkspaceTaskItem[];
} | null> {
  try {
    const [
      proposalsRes,
      clientsRes,
      followUpsRes,
      messagesRes,
      tasksRes,
    ] = await Promise.all([
      supabase.from('proposals').select('*'),
      supabase.from('clients').select('*'),
      supabase.from('follow_ups').select('*'),
      supabase.from('client_messages').select('*'),
      supabase.from('client_tasks').select('*'),
    ]);

    const hasValidData =
      (!proposalsRes.error &&
        Array.isArray(proposalsRes.data) &&
        proposalsRes.data.length > 0) ||
      (!clientsRes.error &&
        Array.isArray(clientsRes.data) &&
        clientsRes.data.length > 0);

    if (!hasValidData) {
      return null;
    }

    const proposals: ProposalItem[] = Array.isArray(proposalsRes.data)
      ? (proposalsRes.data as SupabaseProposalRow[]).map(mapRowToProposal)
      : [];

    const clients: ClientItem[] = Array.isArray(clientsRes.data)
      ? (clientsRes.data as SupabaseClientRow[]).map((row) => ({
          id: row.id,
          name: row.name,
          company: row.company,
          email: row.email,
          industry: row.industry,
          totalProposals: Number(row.total_proposals) || 0,
          pipelineValue: row.pipeline_value,
          lastActivity: row.last_activity,
          status: (row.status as 'Active' | 'Prospect' | 'Won') || 'Active',
        }))
      : [];

    const followUps: FollowUpItem[] = Array.isArray(followUpsRes.data)
      ? (followUpsRes.data as SupabaseFollowUpRow[]).map((row) => ({
          id: row.id,
          proposalId: row.proposal_id,
          proposalTitle: row.proposal_title,
          clientCompany: row.client_company,
          contactName: row.contact_name,
          contactEmail: row.contact_email,
          headline: row.headline,
          subtext: row.subtext,
          timingBadge:
            (row.timing_badge as 'Today' | 'Viewed' | 'Tomorrow' | 'Upcoming') ||
            'Today',
          aiInsight: row.ai_insight,
          suggestedSubject: row.suggested_subject,
          suggestedMessage: row.suggested_message,
          sent: Boolean(row.sent),
        }))
      : [];

    const clientMessages: ClientMessageItem[] = Array.isArray(messagesRes.data)
      ? (messagesRes.data as SupabaseMessageRow[]).map((row) => ({
          id: row.id,
          proposalId: row.proposal_id,
          clientCompany: row.client_company,
          senderName: row.sender_name,
          senderRole: (row.sender_role as 'client' | 'agency') || 'agency',
          messageText: row.message_text,
          timeLabel: row.time_label,
        }))
      : [];

    const clientTasks: ClientWorkspaceTaskItem[] = Array.isArray(tasksRes.data)
      ? (tasksRes.data as SupabaseTaskRow[]).map((row) => ({
          id: row.id,
          clientCompany: row.client_company,
          title: row.title,
          category:
            (row.category as
              | 'Task'
              | 'Deadline'
              | 'Meeting'
              | 'Project Update') || 'Task',
          dueDate: row.due_date,
          status:
            (row.status as 'Pending' | 'In Progress' | 'Completed') ||
            'Pending',
          notes: row.notes,
        }))
      : [];

    return {
      proposals,
      clients,
      followUps,
      clientMessages,
      clientTasks,
    };
  } catch {
    return null;
  }
}

export async function upsertProposalInSupabase(
  proposal: ProposalItem
): Promise<void> {
  try {
    const payload: SupabaseProposalRow = {
      id: proposal.id,
      title: proposal.title,
      client_name: proposal.clientName,
      client_company: proposal.clientCompany,
      client_email: proposal.clientEmail,
      industry: proposal.industry,
      value: proposal.value,
      numeric_value: proposal.numericValue,
      status: proposal.status,
      updated_at_label: proposal.updatedAt,
      style: proposal.style,
      timeline_summary: proposal.timelineSummary,
      services_json: JSON.stringify(proposal.services || []),
      sections_json: JSON.stringify(proposal.sections || {}),
    };
    await supabase.from('proposals').upsert(payload, { onConflict: 'id' });
  } catch {
    // Fallback handled by local state & Cloud SQL backend
  }
}

export async function deleteProposalInSupabase(
  proposalId: string
): Promise<void> {
  try {
    await supabase.from('proposals').delete().eq('id', proposalId);
  } catch {
    // Fallback handled by local state & Cloud SQL backend
  }
}

export async function upsertClientInSupabase(client: ClientItem): Promise<void> {
  try {
    const payload: SupabaseClientRow = {
      id: client.id,
      name: client.name,
      company: client.company,
      email: client.email,
      industry: client.industry,
      total_proposals: client.totalProposals,
      pipeline_value: client.pipelineValue,
      last_activity: client.lastActivity,
      status: client.status,
    };
    await supabase.from('clients').upsert(payload, { onConflict: 'id' });
  } catch {
    // Fallback handled by local state & Cloud SQL backend
  }
}

export async function upsertFollowUpInSupabase(
  followUp: FollowUpItem
): Promise<void> {
  try {
    const payload: SupabaseFollowUpRow = {
      id: followUp.id,
      proposal_id: followUp.proposalId,
      proposal_title: followUp.proposalTitle,
      client_company: followUp.clientCompany,
      contact_name: followUp.contactName,
      contact_email: followUp.contactEmail,
      headline: followUp.headline,
      subtext: followUp.subtext,
      timing_badge: followUp.timingBadge,
      ai_insight: followUp.aiInsight,
      suggested_subject: followUp.suggestedSubject,
      suggested_message: followUp.suggestedMessage,
      sent: followUp.sent,
    };
    await supabase.from('follow_ups').upsert(payload, { onConflict: 'id' });
  } catch {
    // Fallback handled by local state & Cloud SQL backend
  }
}

export async function insertClientMessageInSupabase(
  message: ClientMessageItem
): Promise<void> {
  try {
    const payload: SupabaseMessageRow = {
      id: message.id,
      proposal_id: message.proposalId,
      client_company: message.clientCompany,
      sender_name: message.senderName,
      sender_role: message.senderRole,
      message_text: message.messageText,
      time_label: message.timeLabel,
    };
    await supabase.from('client_messages').upsert(payload, { onConflict: 'id' });
  } catch {
    // Fallback handled by local state & Cloud SQL backend
  }
}

export async function upsertClientTaskInSupabase(
  task: ClientWorkspaceTaskItem
): Promise<void> {
  try {
    const payload: SupabaseTaskRow = {
      id: task.id,
      client_company: task.clientCompany,
      title: task.title,
      category: task.category,
      due_date: task.dueDate,
      status: task.status,
      notes: task.notes,
    };
    await supabase.from('client_tasks').upsert(payload, { onConflict: 'id' });
  } catch {
    // Fallback handled by local state & Cloud SQL backend
  }
}

export async function saveWorkspaceSetupInSupabase(setup: {
  companyName: string;
  industry: string;
  servicesOffered: string;
  brandColor: string;
  typicalClientType: string;
  currency: string;
  proposalTone: string;
}): Promise<void> {
  try {
    await supabase.from('workspace_settings').upsert(
      {
        id: 'default_workspace',
        company_name: setup.companyName,
        industry: setup.industry,
        services_offered: setup.servicesOffered,
        brand_color: setup.brandColor,
        typical_client_type: setup.typicalClientType,
        currency: setup.currency,
        proposal_tone: setup.proposalTone,
        updated_at: new Date().toISOString(),
      },
      { onConflict: 'id' }
    );
  } catch {
    // Fallback handled by local state & Cloud SQL backend
  }
}

export async function syncUserInSupabase(
  displayName?: string,
  workspaceName?: string,
  email?: string
): Promise<void> {
  try {
    await supabase.from('users').upsert(
      {
        uid: email || 'alex@zendo.ai',
        email: email || 'alex@zendo.ai',
        display_name: displayName || 'Alex Morgan',
        workspace_name: workspaceName || 'Zendo Studio',
      },
      { onConflict: 'uid' }
    );
  } catch {
    // Fallback handled by local state & Cloud SQL backend
  }
}
