/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import {
  ArrowRight,
  Check,
  Plus,
  Copy,
  PieChart,
  Layers,
  Sparkles,
  BarChart3,
  Target,
  Command,
} from 'lucide-react';
import {
  ZENDO_COPY,
  INITIAL_TASKS,
  INITIAL_PROJECTS,
  INITIAL_NOTES,
  INITIAL_AUTOMATIONS,
  INITIAL_TEAM,
  INITIAL_ACTIVITY,
  TaskItem,
  ProjectItem,
  WorkspaceNote,
  AutomationRule,
  TeamMember,
  ActivityLogItem,
} from './data/zendoCopy';
import { ScrollRevealText } from './components/ScrollRevealText';
import { DashboardView } from './components/DashboardView';
import { AuthModal } from './components/AuthModal';
import { AuthPage } from './components/AuthPage';
import {
  OnboardingSetupPage,
  WorkspaceOnboardingConfig,
} from './components/OnboardingSetupPage';
import { CopyKitDrawer } from './components/CopyKitDrawer';
import { ZendoLogo } from './components/ZendoLogo';
import { CommandPalette, WorkspaceSection } from './components/CommandPalette';
import { FeatureShowcaseBoxes } from './components/FeatureShowcaseBoxes';
import { ZendoHeroShowcase } from './components/ZendoHeroShowcase';
import { ScrollingReviews } from './components/ScrollingReviews';
import {
  auth,
  db,
  HAS_FIRESTORE_DB,
  googleSignIn,
  onAuthStateChanged,
  signOutZendo,
  getStoredAuthSession,
  saveStoredAuthSession,
  collection,
  onSnapshot,
  ensureUserProfileInFirestore,
  updateUserProfilePlanInFirestore,
  createTaskInFirestore,
  updateTaskInFirestore,
  deleteTaskFromFirestore,
  handleFirestoreError,
  OperationType,
  sanitizeId,
  type User,
} from './firebase';
import { syncUserToBackend, saveWorkspaceSetupToBackend } from './lib/api';
import skyMeadowHeroImage from './assets/images/sky_clouds_meadow_hero_1791383712836.jpg';
import editorialPortrait from './assets/images/editorial_founder_portrait_1791381634277.jpg';
import founderAvatar from './assets/images/avatar_team_lead_1791380135632.jpg';

const DAILY_FLOW_BARS = [
  { day: 'Day 01', height: 42, value: '12 tasks', active: false },
  { day: 'Day 02', height: 54, value: '15 tasks', active: false },
  { day: 'Day 03', height: 48, value: '14 tasks', active: false },
  { day: 'Day 04', height: 66, value: '19 tasks', active: true },
  { day: 'Day 05', height: 60, value: '17 tasks', active: false },
  { day: 'Day 06', height: 52, value: '15 tasks', active: false },
  { day: 'Day 07', height: 72, value: '21 tasks', active: true },
  { day: 'Day 08', height: 68, value: '20 tasks', active: false },
  { day: 'Day 09', height: 58, value: '16 tasks', active: false },
  { day: 'Day 10', height: 78, value: '23 tasks', active: true },
  { day: 'Day 11', height: 74, value: '22 tasks', active: false },
  { day: 'Day 12', height: 84, value: '25 tasks', active: true },
  { day: 'Day 13', height: 70, value: '20 tasks', active: false },
  { day: 'Day 14', height: 88, value: '27 tasks', active: true },
  { day: 'Day 15', height: 82, value: '24 tasks', active: false },
  { day: 'Day 16', height: 96, value: '29 tasks', active: true },
];

const CONNECTED_TOOLS = [
  { name: 'Google Calendar', category: 'Schedule' },
  { name: 'Slack', category: 'Messaging' },
  { name: 'Notion', category: 'Docs & Notes' },
  { name: 'Linear', category: 'Issue Tracking' },
  { name: 'GitHub', category: 'Repositories' },
  { name: 'Figma', category: 'Design Files' },
  { name: 'Gmail', category: 'Inbox' },
  { name: 'HubSpot', category: 'Customer Ops' },
  { name: 'Asana', category: 'Project Boards' },
  { name: 'Trello', category: 'Kanban Cards' },
  { name: 'Mixpanel', category: 'Product Signals' },
  { name: 'Zapier', category: 'Routines' },
];

const FAQ_ITEMS = [
  {
    q: 'What does Zendo bring together?',
    a: 'Zendo brings your daily tasks, multi-step projects, team notes, and recurring workflow routines into one calm, unified workspace—replacing scattered boards and disconnected to-do lists.',
  },
  {
    q: 'How do workflow automations work in Zendo?',
    a: 'You can set simple, human-readable rules in seconds—such as automatically assigning follow-ups, archiving completed tasks, or preparing your morning priority queue without complex setup.',
  },
  {
    q: 'Is Zendo really free to start?',
    a: 'Yes. You can use Zendo for free with no credit card required. Upgrade to Pro or Team only when your workflow grows and you need unlimited automations or team-wide permissions.',
  },
  {
    q: 'Can I switch from tools like Notion, Trello, or Asana?',
    a: 'Yes. You can bring your tasks, projects, and priorities into Zendo in less than a minute and immediately organize them into Today’s Tasks, In Progress, and Upcoming Deadlines.',
  },
  {
    q: 'How does Zendo help reduce meetings and busywork?',
    a: 'By keeping task ownership, status updates, and next steps visible in one shared view, teams stay aligned asynchronously without daily status check-ins.',
  },
];

const STORAGE_KEY = 'zendo_saas_workspace_v2';

export default function App() {
  const [activeView, setActiveView] = useState<
    'website' | 'auth' | 'onboarding' | 'dashboard'
  >(() => {
    try {
      const path = window.location.pathname;
      if (path === '/dashboard') {
        return 'dashboard';
      }
      if (path === '/login' || path === '/auth') {
        return 'auth';
      }
    } catch {
      // ignore
    }
    return 'website';
  });
  const [workspaceSection, setWorkspaceSection] = useState<WorkspaceSection>('tasks');
  const [copyMode, setCopyMode] = useState<'zendo' | 'metrivello'>('zendo');
  const [userName, setUserName] = useState<string>(() => {
    const session = getStoredAuthSession();
    if (session?.displayName) return session.displayName;
    try {
      const saved = localStorage.getItem(STORAGE_KEY);
      if (saved) {
        const parsed = JSON.parse(saved);
        if (parsed.userName) return parsed.userName;
      }
    } catch {
      // ignore
    }
    return 'Findify Ai';
  });
  const [userEmail, setUserEmail] = useState<string>(() => {
    const session = getStoredAuthSession();
    if (session?.email) return session.email;
    try {
      const saved = localStorage.getItem(STORAGE_KEY);
      if (saved) {
        const parsed = JSON.parse(saved);
        if (parsed.userEmail) return parsed.userEmail;
      }
    } catch {
      // ignore
    }
    return 'findifyai@gmail.com';
  });
  const [userPhotoUrl, setUserPhotoUrl] = useState<string | undefined>(() => {
    const session = getStoredAuthSession();
    return session?.photoURL;
  });
  const [activePlan, setActivePlan] = useState<'Free' | 'Pro' | 'Team'>(() => {
    const session = getStoredAuthSession();
    if (session?.activePlan) return session.activePlan;
    return 'Pro';
  });
  const [onboardingConfig, setOnboardingConfig] = useState<
    WorkspaceOnboardingConfig | undefined
  >(() => {
    try {
      const saved = localStorage.getItem(STORAGE_KEY);
      if (saved) {
        const parsed = JSON.parse(saved);
        if (parsed.onboardingConfig) return parsed.onboardingConfig;
      }
    } catch {
      // ignore
    }
    return undefined;
  });
  const [firebaseUser, setFirebaseUser] = useState<User | null>(null);
  const [isAuthReady, setIsAuthReady] = useState(false);
  const [isProfileReady, setIsProfileReady] = useState(false);

  const [tasks, setTasks] = useState<TaskItem[]>(() => {
    try {
      const saved = localStorage.getItem(STORAGE_KEY);
      if (saved) {
        const parsed = JSON.parse(saved);
        if (Array.isArray(parsed.tasks) && parsed.tasks.length > 0) return parsed.tasks;
      }
    } catch {
      // ignore storage errors
    }
    return INITIAL_TASKS;
  });

  const [projects, setProjects] = useState<ProjectItem[]>(() => {
    try {
      const saved = localStorage.getItem(STORAGE_KEY);
      if (saved) {
        const parsed = JSON.parse(saved);
        if (Array.isArray(parsed.projects) && parsed.projects.length > 0)
          return parsed.projects;
      }
    } catch {
      // ignore
    }
    return INITIAL_PROJECTS;
  });

  const [notes, setNotes] = useState<WorkspaceNote[]>(() => {
    try {
      const saved = localStorage.getItem(STORAGE_KEY);
      if (saved) {
        const parsed = JSON.parse(saved);
        if (Array.isArray(parsed.notes) && parsed.notes.length > 0) return parsed.notes;
      }
    } catch {
      // ignore
    }
    return INITIAL_NOTES;
  });

  const [automations, setAutomations] =
    useState<AutomationRule[]>(INITIAL_AUTOMATIONS);
  const [team, setTeam] = useState<TeamMember[]>(INITIAL_TEAM);
  const [activityLog, setActivityLog] =
    useState<ActivityLogItem[]>(INITIAL_ACTIVITY);
  const [inspectedTaskId, setInspectedTaskId] = useState<string | null>(null);
  const [selectedNoteId, setSelectedNoteId] = useState<string | null>(
    INITIAL_NOTES[0].id
  );

  // Calm Focus Timer state (25:00 default)
  const [focusSeconds, setFocusSeconds] = useState(25 * 60);
  const [focusRunning, setFocusRunning] = useState(false);
  const [focusTaskTitle, setFocusTaskTitle] = useState<string | null>(null);

  // Command Palette & Toast state
  const [commandPaletteOpen, setCommandPaletteOpen] = useState(false);
  const [toastMessage, setToastMessage] = useState<string | null>(null);

  // Hero Headline index
  const [activeHeadlineIndex, setActiveHeadlineIndex] = useState(0);

  // Hero Dashboard Shell interactive state
  const [heroShellTab, setHeroShellTab] = useState<
    'overview' | 'today' | 'in_progress' | 'completed' | 'empty_states'
  >('overview');
  const [selectedEmptyKey, setSelectedEmptyKey] = useState<
    'noTasks' | 'allCaughtUp' | 'noProjects' | 'nothingOverdue'
  >('allCaughtUp');
  const [hoveredBarIdx, setHoveredBarIdx] = useState<number | null>(15);

  // Pricing Billing Switcher
  const [billingCycle, setBillingCycle] = useState<'yearly' | 'monthly'>('yearly');

  // FAQ Accordion state
  const [openFaqIndex, setOpenFaqIndex] = useState<number | null>(0);

  // Modals & Drawers
  const [authModalOpen, setAuthModalOpen] = useState(false);
  const [authInitialMode, setAuthInitialMode] = useState<'login' | 'signup'>('login');
  const [copyKitOpen, setCopyKitOpen] = useState(false);
  const [copiedId, setCopiedId] = useState<string | null>(null);

  // Inline Google Auth state
  const [inlineAuthLoading, setInlineAuthLoading] = useState(false);
  const [inlineAuthError, setInlineAuthError] = useState('');

  // Image error fallback flags
  const [skyImgError, setSkyImgError] = useState(false);
  const [portraitImgError, setPortraitImgError] = useState(false);
  const [founderImgError, setFounderImgError] = useState(false);

  const showToast = (msg: string) => {
    setToastMessage(msg);
    setTimeout(() => {
      setToastMessage((prev) => (prev === msg ? null : prev));
    }, 3200);
  };

  // Persist workspace data to localStorage
  useEffect(() => {
    try {
      localStorage.setItem(
        STORAGE_KEY,
        JSON.stringify({
          tasks,
          projects,
          notes,
          userName,
          userEmail,
          activePlan,
          onboardingConfig,
        })
      );
    } catch {
      // ignore
    }
  }, [tasks, projects, notes, userName, userEmail, activePlan, onboardingConfig]);

  // Listen to Firebase Auth state and initialize user profile
  useEffect(() => {
    const unsubAuth = onAuthStateChanged(auth, (fbUser) => {
      setFirebaseUser(fbUser);
      setIsAuthReady(true);
      if (fbUser) {
        const resolvedName =
          fbUser.displayName?.trim() ||
          fbUser.email?.split('@')[0] ||
          'Findify Ai';
        const resolvedEmail = fbUser.email || 'findifyai@gmail.com';
        setUserName(resolvedName);
        setUserEmail(resolvedEmail);
        if (fbUser.photoURL) setUserPhotoUrl(fbUser.photoURL);
        setIsProfileReady(true);
        saveStoredAuthSession({
          uid: fbUser.uid,
          displayName: resolvedName,
          email: resolvedEmail,
          photoURL: fbUser.photoURL || undefined,
        });

        setActiveView((currentView) => {
          if (currentView === 'auth') {
            try {
              window.history.pushState({}, '', '/onboarding');
            } catch {
              // ignore
            }
            return 'onboarding';
          }
          return currentView;
        });

        void ensureUserProfileInFirestore(fbUser, resolvedName)
          .then((profile) => {
            if (profile.displayName) setUserName(profile.displayName);
            if (profile.activePlan) setActivePlan(profile.activePlan);
          })
          .catch(() => {});
      } else {
        const session = getStoredAuthSession();
        if (session) {
          setUserName(session.displayName);
          setUserEmail(session.email);
          setUserPhotoUrl(session.photoURL);
          setIsProfileReady(true);
        } else {
          setIsProfileReady(false);
          setUserPhotoUrl(undefined);
        }
      }
    });
    return () => unsubAuth();
  }, []);

  // Attach real-time Firestore listener for /users/{uid}/tasks only when Firestore is provisioned
  useEffect(() => {
    if (!HAS_FIRESTORE_DB || !isAuthReady || !firebaseUser || !isProfileReady)
      return;
    const uid = sanitizeId(firebaseUser.uid);
    const tasksPath = `users/${uid}/tasks`;
    const tasksCol = collection(db, 'users', uid, 'tasks');

    const unsubTasks = onSnapshot(
      tasksCol,
      (snapshot) => {
        if (snapshot.empty) {
          // Seed initial tasks into Firestore for a new verified user
          if (firebaseUser.emailVerified) {
            INITIAL_TASKS.forEach((initialTask) => {
              createTaskInFirestore(firebaseUser, initialTask).catch(() => {});
            });
          }
          return;
        }
        const remoteTasks: TaskItem[] = snapshot.docs.map((docSnap) => {
          const data = docSnap.data();
          const mappedPriority: TaskItem['priority'] =
            data.priority === 'High'
              ? 'High'
              : data.priority === 'Medium'
              ? 'Medium'
              : 'Calm';
          const mappedStatus: TaskItem['status'] =
            data.status === 'completed'
              ? 'completed'
              : data.status === 'in_progress'
              ? 'in_progress'
              : 'today';
          return {
            id: data.id || docSnap.id,
            title: data.title || 'Untitled Task',
            description: data.notes || '',
            project: data.project || 'Product Strategy',
            status: mappedStatus,
            priority: mappedPriority,
            dueDate: data.due || 'Today',
            assignee: data.assignee || userName,
            automated: mappedPriority === 'High',
            subtasks: [],
            comments: [],
          };
        });
        setTasks(remoteTasks);
      },
      (err) => {
        handleFirestoreError(err, OperationType.LIST, tasksPath);
      }
    );

    return () => unsubTasks();
  }, [isAuthReady, firebaseUser, isProfileReady]);

  // Global Cmd+K / Ctrl+K shortcut
  useEffect(() => {
    const onKeyDown = (e: KeyboardEvent) => {
      if ((e.metaKey || e.ctrlKey) && e.key.toLowerCase() === 'k') {
        e.preventDefault();
        setCommandPaletteOpen((prev) => !prev);
      }
    };
    window.addEventListener('keydown', onKeyDown);
    return () => window.removeEventListener('keydown', onKeyDown);
  }, []);

  // Calm Focus Timer countdown
  useEffect(() => {
    if (!focusRunning) return;
    const timer = setInterval(() => {
      setFocusSeconds((prev) => {
        if (prev <= 1) {
          setFocusRunning(false);
          showToast('25m Calm Focus block completed! Take a 5-minute breath.');
          return 25 * 60;
        }
        return prev - 1;
      });
    }, 1000);
    return () => clearInterval(timer);
  }, [focusRunning]);

  const logActivity = (
    actor: string,
    action: string,
    target: string,
    type: ActivityLogItem['type'] = 'task'
  ) => {
    setActivityLog((prev) => [
      {
        id: `act-${Date.now()}`,
        actor,
        action,
        target,
        timestamp: 'Just now',
        type,
      },
      ...prev,
    ]);
  };

  const handleToggleTaskStatus = (id: string) => {
    const existingTask = tasks.find((t) => t.id === id);
    if (!existingTask) return;

    const nextStatus: TaskItem['status'] =
      existingTask.status === 'completed'
        ? 'today'
        : existingTask.status === 'today'
        ? 'in_progress'
        : 'completed';
    const updatedTask: TaskItem = {
      ...existingTask,
      status: nextStatus,
      dueDate:
        nextStatus === 'completed' ? 'Completed · Just now' : 'Today · Priority',
    };

    setTasks((prev) => prev.map((t) => (t.id === id ? updatedTask : t)));

    if (nextStatus === 'completed') {
      logActivity(userName, 'Completed task', existingTask.title, 'task');
      showToast(`Completed: "${existingTask.title}"`);
    }

    if (firebaseUser) {
      updateTaskInFirestore(firebaseUser, existingTask.status, updatedTask).catch(
        (err) => console.error(err)
      );
    }
  };

  const handleAddTask = (
    title: string,
    project: string,
    priority: TaskItem['priority'],
    status: TaskItem['status'] = 'today',
    assignee: string = userName,
    description?: string
  ) => {
    const newTask: TaskItem = {
      id: `tsk_${Date.now()}`,
      title,
      description:
        description ||
        'Focused priority item tracked inside Zendo Workspace.',
      project,
      status,
      priority,
      dueDate: 'Today · 5:00 PM',
      assignee,
      automated: priority === 'High',
      subtasks: [
        { id: `st_${Date.now()}_1`, title: 'Define scope & next step', completed: false },
      ],
      comments: [],
    };
    setTasks((prev) => [newTask, ...prev]);
    logActivity(userName, 'Created task', title, 'task');
    showToast(`Added "${title}" to ${project}`);

    if (firebaseUser) {
      createTaskInFirestore(firebaseUser, newTask).catch((err) =>
        console.error(err)
      );
    }
  };

  const handleUpdateTask = (updatedTask: TaskItem) => {
    const previousTask = tasks.find((t) => t.id === updatedTask.id);
    setTasks((prev) =>
      prev.map((t) => (t.id === updatedTask.id ? updatedTask : t))
    );
    if (firebaseUser && previousTask) {
      updateTaskInFirestore(
        firebaseUser,
        previousTask.status,
        updatedTask
      ).catch((err) => console.error(err));
    }
  };

  const handleDeleteTask = (id: string) => {
    const target = tasks.find((t) => t.id === id);
    setTasks((prev) => prev.filter((t) => t.id !== id));
    if (target) {
      logActivity(userName, 'Removed task', target.title, 'task');
      showToast(`Removed task "${target.title}"`);
    }
    if (firebaseUser) {
      deleteTaskFromFirestore(firebaseUser, id).catch((err) =>
        console.error(err)
      );
    }
  };

  const handleAddProject = (
    name: string,
    description = 'Focused workflow initiative organized in Zendo.',
    lead = userName
  ) => {
    const palette = ['#0c9256', '#18a165', '#256149', '#0d9488'];
    const newProj: ProjectItem = {
      id: `prj-${Date.now()}`,
      name,
      description,
      taskCount: 1,
      completionRate: 100,
      lead,
      color: palette[projects.length % palette.length],
    };
    setProjects((prev) => [...prev, newProj]);
    logActivity(userName, 'Created project', name, 'project');
    showToast(`Created project "${name}"`);
  };

  const handleDeleteProject = (id: string) => {
    setProjects((prev) => prev.filter((p) => p.id !== id));
    showToast('Project removed');
  };

  const handleAddNote = (
    title: string,
    project: string,
    content: string
  ): WorkspaceNote => {
    const newNote: WorkspaceNote = {
      id: `note-${Date.now()}`,
      title,
      project,
      content,
      updatedAt: 'Just now',
      author: userName,
      pinned: false,
    };
    setNotes((prev) => [newNote, ...prev]);
    logActivity(userName, 'Created workspace note', title, 'note');
    showToast(`Created note "${title}"`);
    return newNote;
  };

  const handleUpdateNote = (updated: WorkspaceNote) => {
    setNotes((prev) => prev.map((n) => (n.id === updated.id ? updated : n)));
  };

  const handleDeleteNote = (id: string) => {
    setNotes((prev) => {
      const remaining = prev.filter((n) => n.id !== id);
      if (selectedNoteId === id && remaining[0]) {
        setSelectedNoteId(remaining[0].id);
      }
      return remaining;
    });
    showToast('Workspace note deleted');
  };

  const handleToggleAutomation = (id: string) => {
    setAutomations((prev) =>
      prev.map((a) => (a.id === id ? { ...a, enabled: !a.enabled } : a))
    );
  };

  const handleRunAutomation = (id: string) => {
    const rule = automations.find((a) => a.id === id);
    if (!rule) return;
    setAutomations((prev) =>
      prev.map((a) =>
        a.id === id
          ? { ...a, runsCount: a.runsCount + 1, lastTriggered: 'Just now' }
          : a
      )
    );
    logActivity('Zendo Automation', `Executed "${rule.name}"`, rule.action, 'automation');
    showToast(`Automation executed: ${rule.name}`);
  };

  const handleAddAutomation = (name: string, trigger: string, action: string) => {
    const newRule: AutomationRule = {
      id: `auto-${Date.now()}`,
      name,
      trigger,
      action,
      enabled: true,
      runsCount: 1,
      lastTriggered: 'Just now',
    };
    setAutomations((prev) => [newRule, ...prev]);
    logActivity(userName, 'Enabled automation rule', name, 'automation');
    showToast(`Created automation rule "${name}"`);
  };

  const handleAddTeamMember = (name: string, email: string, role: string) => {
    const initials = name
      .split(' ')
      .map((p) => p[0])
      .join('')
      .slice(0, 2)
      .toUpperCase();
    const member: TeamMember = {
      id: `usr-${Date.now()}`,
      name,
      email,
      role,
      initials: initials || 'ZN',
      status: 'Online',
      tasksAssigned: 1,
    };
    setTeam((prev) => [...prev, member]);
    showToast(`Invited ${name} (${email}) to Zendo Workspace`);
  };

  const handleCycleMemberStatus = (id: string) => {
    setTeam((prev) =>
      prev.map((m) => {
        if (m.id !== id) return m;
        const nextStatus: TeamMember['status'] =
          m.status === 'In Flow'
            ? 'Online'
            : m.status === 'Online'
            ? 'Async'
            : 'In Flow';
        return { ...m, status: nextStatus };
      })
    );
  };

  const handleToggleFocusTimer = (taskTitle?: string) => {
    if (taskTitle) {
      setFocusTaskTitle(taskTitle);
      setFocusRunning(true);
      showToast(`Started 25m Calm Focus Timer on "${taskTitle}"`);
    } else {
      setFocusRunning((prev) => !prev);
    }
  };

  const handleResetFocusTimer = () => {
    setFocusRunning(false);
    setFocusSeconds(25 * 60);
    setFocusTaskTitle(null);
  };

  const handleExportCsv = () => {
    const headers = ['ID', 'Title', 'Project', 'Status', 'Priority', 'Assignee', 'DueDate'];
    const rows = tasks.map((t) => [
      t.id,
      `"${t.title.replace(/"/g, '""')}"`,
      `"${t.project}"`,
      t.status,
      t.priority,
      `"${t.assignee}"`,
      `"${t.dueDate}"`,
    ]);
    const csv = [headers.join(','), ...rows.map((r) => r.join(','))].join('\n');
    const blob = new Blob([csv], { type: 'text/csv;charset=utf-8;' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    link.setAttribute('download', 'zendo-workspace-tasks.csv');
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
    URL.revokeObjectURL(url);
    showToast('Exported workspace snapshot (zendo-workspace-tasks.csv)');
  };

  const handleResetDemoData = () => {
    localStorage.removeItem(STORAGE_KEY);
    setTasks(INITIAL_TASKS);
    setProjects(INITIAL_PROJECTS);
    setNotes(INITIAL_NOTES);
    setAutomations(INITIAL_AUTOMATIONS);
    setTeam(INITIAL_TEAM);
    setActivityLog(INITIAL_ACTIVITY);
    showToast('Workspace reset to default Zendo demo data');
  };

  const handleInlineGoogleLogin = async () => {
    setInlineAuthError('');
    setInlineAuthLoading(true);
    try {
      const cred = await googleSignIn();
      const resolvedName =
        cred.user.displayName?.trim() ||
        cred.user.email?.split('@')[0] ||
        'Alex Morgan';
      setUserName(resolvedName);
      if (cred.user.email) setUserEmail(cred.user.email);
      if (cred.user.photoURL) setUserPhotoUrl(cred.user.photoURL);
      setInlineAuthLoading(false);
      try {
        window.history.pushState({}, '', '/onboarding');
      } catch {
        // ignore
      }
      setActiveView('onboarding');
      showToast(`Welcome ${resolvedName}! Please answer a few quick questions about your business.`);
      window.scrollTo({ top: 0, behavior: 'smooth' });

      void ensureUserProfileInFirestore(cred.user, resolvedName).then((profile) =>
        syncUserToBackend(profile.displayName, profile.workspaceName)
      );
    } catch (err: unknown) {
      setInlineAuthLoading(false);
      const msg = err instanceof Error ? err.message : String(err);
      setInlineAuthError(msg.replace('Firebase: ', ''));
    }
  };

  const handleCompleteOnboarding = (config: WorkspaceOnboardingConfig) => {
    setOnboardingConfig(config);

    // Save business questionnaire responses to SQL backend & profile
    void saveWorkspaceSetupToBackend({
      companyName: config.companyName,
      industry: config.industry,
      servicesOffered: config.services.join(', '),
      brandColor: config.brandColor,
      typicalClientType: config.clientType,
      currency: config.currency,
      proposalTone: config.proposalTone,
    });

    // Seed a personalized first winning proposal task and note into the user's workspace
    const primaryService = config.services[0] || 'Strategic Proposal';
    const proposalTaskTitle = `Send ${config.companyName} ${primaryService} Proposal (${config.currency})`;
    const alreadyExists = tasks.some((t) => t.title === proposalTaskTitle);

    if (!alreadyExists) {
      handleAddTask(
        proposalTaskTitle,
        'Product Strategy',
        'High',
        'today',
        userName,
        `Tailored ${config.proposalTone.toLowerCase()} proposal for ${config.clientType} in ${config.industry}. Services included: ${config.services.join(', ')}.`
      );
    }

    if (firebaseUser) {
      ensureUserProfileInFirestore(
        firebaseUser,
        userName,
        config.companyName,
        activePlan
      ).catch(() => {});
    }

    try {
      window.history.pushState({}, '', '/dashboard');
    } catch {
      // ignore
    }
    setActiveView('dashboard');
    showToast(
      `Workspace set up for ${config.companyName} (${config.proposalTone} tone · ${config.currency})`
    );
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  const handleCopyText = (id: string, text: string) => {
    navigator.clipboard.writeText(text);
    setCopiedId(id);
    setTimeout(() => setCopiedId(null), 1500);
  };

  const todayCount = tasks.filter((t) => t.status === 'today').length;
  const inProgressCount = tasks.filter((t) => t.status === 'in_progress').length;
  const completedCount = tasks.filter((t) => t.status === 'completed').length;
  const upcomingCount = tasks.filter((t) => t.status !== 'completed').length;

  const commandPaletteNode = (
    <CommandPalette
      isOpen={commandPaletteOpen}
      onClose={() => setCommandPaletteOpen(false)}
      tasks={tasks}
      projects={projects}
      notes={notes}
      automations={automations}
      onNavigateView={(v) => {
        setActiveView(v);
        window.scrollTo({ top: 0, behavior: 'smooth' });
      }}
      onSelectWorkspaceSection={(sec) => setWorkspaceSection(sec)}
      onInspectTask={(taskId) => {
        setWorkspaceSection('tasks');
        setInspectedTaskId(taskId);
      }}
      onQuickCreateTask={(title) => {
        handleAddTask(title, 'Product Strategy', 'High', 'today', userName);
        setActiveView('dashboard');
        setWorkspaceSection('tasks');
      }}
      onSelectProject={() => {
        setWorkspaceSection('projects');
      }}
      onSelectNote={(noteId) => {
        setWorkspaceSection('notes');
        setSelectedNoteId(noteId);
      }}
      onRunAutomation={(ruleId) => {
        handleRunAutomation(ruleId);
        setWorkspaceSection('automations');
      }}
      onStartFocusTimer={() => handleToggleFocusTimer('Deep Focus Session')}
      onExportCsv={handleExportCsv}
      onOpenCopyKit={() => setCopyKitOpen(true)}
    />
  );

  if (activeView === 'auth') {
    return (
      <>
        <AuthPage
          initialMode={authInitialMode}
          onSuccess={(name, email, workspaceName) => {
            const resolvedName = name || 'Findify Ai';
            const resolvedEmail = email || 'findifyai@gmail.com';
            setUserName(resolvedName);
            setUserEmail(resolvedEmail);
            if (workspaceName) {
              setOnboardingConfig((prev) =>
                prev
                  ? { ...prev, companyName: workspaceName }
                  : {
                      companyName: workspaceName,
                      industry: 'Design & Creative Agency',
                      services: ['Brand Identity', 'Web Design & Build', 'Product Strategy'],
                      brandColor: '#3b664e',
                      logoUrl: null,
                      logoMonogram:
                        workspaceName
                          .split(' ')
                          .map((w) => w[0])
                          .join('')
                          .slice(0, 2)
                          .toUpperCase() || 'NS',
                      clientType: 'Growth-Stage Startups',
                      currency: 'USD ($)',
                      proposalTone: 'Professional',
                    }
              );
            }
            try {
              window.history.pushState({}, '', '/onboarding');
            } catch {
              // ignore
            }
            setActiveView('onboarding');
            showToast(`Welcome ${resolvedName}! Please share a few details about your business.`);
            window.scrollTo({ top: 0, behavior: 'smooth' });
          }}
          onBackToHome={() => {
            try {
              window.history.pushState({}, '', '/');
            } catch {
              // ignore
            }
            setActiveView('website');
            window.scrollTo({ top: 0, behavior: 'smooth' });
          }}
          onOpenDashboard={() => {
            try {
              window.history.pushState({}, '', '/dashboard');
            } catch {
              // ignore
            }
            setActiveView('dashboard');
            window.scrollTo({ top: 0, behavior: 'smooth' });
          }}
          onOpenCopyKit={() => setCopyKitOpen(true)}
        />
        {commandPaletteNode}
        <CopyKitDrawer
          isOpen={copyKitOpen}
          onClose={() => setCopyKitOpen(false)}
          activeHeadline={ZENDO_COPY.hero.alternativeHeadlines[activeHeadlineIndex]}
          onApplyHeadline={(hl) => {
            const idx = ZENDO_COPY.hero.alternativeHeadlines.indexOf(hl);
            if (idx !== -1) setActiveHeadlineIndex(idx);
            setCopyKitOpen(false);
            setActiveView('website');
          }}
        />
      </>
    );
  }

  if (activeView === 'onboarding') {
    return (
      <>
        <OnboardingSetupPage
          userName={userName}
          initialWorkspaceName={onboardingConfig?.companyName || 'Northstar Studio'}
          initialConfig={onboardingConfig}
          onComplete={handleCompleteOnboarding}
          onSkipToDashboard={() => {
            try {
              window.history.pushState({}, '', '/dashboard');
            } catch {
              // ignore
            }
            setActiveView('dashboard');
            window.scrollTo({ top: 0, behavior: 'smooth' });
          }}
          onBackToHome={() => {
            try {
              window.history.pushState({}, '', '/');
            } catch {
              // ignore
            }
            setActiveView('website');
            window.scrollTo({ top: 0, behavior: 'smooth' });
          }}
        />
        {commandPaletteNode}
      </>
    );
  }

  if (activeView === 'dashboard') {
    return (
      <>
        <DashboardView
          userName={userName}
          userEmail={userEmail}
          userPhotoUrl={userPhotoUrl}
          onUpdateUserName={setUserName}
          onboardingConfig={onboardingConfig}
          onReopenOnboarding={() => {
            try {
              window.history.pushState({}, '', '/onboarding');
            } catch {
              // ignore
            }
            setActiveView('onboarding');
            window.scrollTo({ top: 0, behavior: 'smooth' });
          }}
          activePlan={activePlan}
          onChangePlan={(plan) => {
            setActivePlan(plan);
            showToast(`Switched workspace plan to Zendo ${plan}`);
            if (firebaseUser) {
              updateUserProfilePlanInFirestore(firebaseUser, plan).catch((err) =>
                console.error(err)
              );
            }
          }}
          onBackToSite={() => {
            try {
              window.history.pushState({}, '', '/');
            } catch {
              // ignore
            }
            setActiveView('website');
            window.scrollTo({ top: 0, behavior: 'smooth' });
          }}
          onLogout={() => {
            void signOutZendo();
            try {
              window.history.pushState({}, '', '/');
            } catch {
              // ignore
            }
            setActiveView('website');
            showToast('Logged out of zendo.ai');
            window.scrollTo({ top: 0, behavior: 'smooth' });
          }}
          tasks={tasks}
          firebaseUser={firebaseUser}
        />
        {commandPaletteNode}
        <CopyKitDrawer
          isOpen={copyKitOpen}
          onClose={() => setCopyKitOpen(false)}
          activeHeadline={ZENDO_COPY.hero.alternativeHeadlines[activeHeadlineIndex]}
          onApplyHeadline={(hl) => {
            const idx = ZENDO_COPY.hero.alternativeHeadlines.indexOf(hl);
            if (idx !== -1) setActiveHeadlineIndex(idx);
            setCopyKitOpen(false);
            setActiveView('website');
          }}
        />
      </>
    );
  }

  const currentHeroHeadline =
    copyMode === 'metrivello'
      ? 'Know what works. Know what to do next.'
      : ZENDO_COPY.hero.alternativeHeadlines[activeHeadlineIndex];

  const heroEyebrow =
    copyMode === 'metrivello'
      ? 'AI MARKETING ANALYTICS'
      : 'CALM PRODUCTIVITY & WORKFLOW';

  const heroSubheadline =
    copyMode === 'metrivello'
      ? 'Bring your marketing tools into one clear view. AI that explains performance, flags changes, and helps you plan your next move.'
      : ZENDO_COPY.hero.subheadline;

  const heroPrimaryBtn =
    copyMode === 'metrivello' ? 'Get a demo' : ZENDO_COPY.hero.primaryButton;

  const heroSecondaryBtn =
    copyMode === 'metrivello'
      ? 'See how it works'
      : ZENDO_COPY.hero.secondaryButton;

  const heroSupportingText =
    copyMode === 'metrivello'
      ? 'Your channels. Your numbers. A clearer picture.'
      : ZENDO_COPY.hero.supportingText;

  return (
    <div className="min-h-screen bg-[#f5f9f7] text-[#101c19] flex flex-col selection:bg-[#0c9256]/15 selection:text-[#087443]">
      {/* =====================================================================
          UPPER SIDE: TOP WHITE ROUNDED NAVIGATION BAR + SKY & CLOUDS HERO
          Matches Screenshot 2026-10-07 073401.png 1:1
      ===================================================================== */}
      <div className="sticky top-0 z-40 px-2 sm:px-4 pt-1.5 pb-1 bg-transparent">
        <header className="max-w-[1420px] mx-auto h-[68px] sm:h-[74px] bg-white rounded-[20px] sm:rounded-[24px] px-5 sm:px-8 flex items-center justify-between shadow-[0_2px_16px_rgba(16,28,25,0.04)] border border-[#e1e9e4]/60">
          {/* Zone 1: Brand Logo Icon + Wordmark */}
          <a
            href="#product"
            className="inline-flex items-center gap-2.5 text-[21px] sm:text-[23px] font-medium tracking-[-0.03em] text-[#101c19] whitespace-nowrap"
          >
            <ZendoLogo className="w-8 h-8 sm:w-[34px] sm:h-[34px] shrink-0" color="#101c19" />
            <span>{copyMode === 'metrivello' ? 'Metrivello' : ZENDO_COPY.brandName}</span>
          </a>

          {/* Zone 2: Center Navigation Links (Exact Screenshot Layout) */}
          <nav
            aria-label="Primary navigation"
            className="hidden lg:flex items-center gap-6 text-[13.5px] font-normal text-[#101c19]"
          >
            <a
              href="#product"
              className="hover:text-[#0c9256] transition-colors whitespace-nowrap"
            >
              Product
            </a>
            <a
              href="#features"
              className="hover:text-[#0c9256] transition-colors whitespace-nowrap"
            >
              Features
            </a>
            <a
              href="#how-it-works"
              className="hover:text-[#0c9256] transition-colors whitespace-nowrap"
            >
              How It Works
            </a>
            <a
              href="#benefits"
              className="hover:text-[#0c9256] transition-colors whitespace-nowrap"
            >
              Benefits
            </a>
            <a
              href="#stories"
              className="hover:text-[#0c9256] transition-colors whitespace-nowrap"
            >
              Stories
            </a>
            <a
              href="#pricing"
              className="hover:text-[#0c9256] transition-colors whitespace-nowrap"
            >
              Pricing
            </a>
            <a
              href="#resources"
              className="hover:text-[#0c9256] transition-colors whitespace-nowrap"
            >
              Resources
            </a>
            <a
              href="#faq"
              className="hover:text-[#0c9256] transition-colors whitespace-nowrap"
            >
              FAQ
            </a>
            <button
              type="button"
              onClick={() => {
                try {
                  window.history.pushState({}, '', '/dashboard');
                } catch {
                  // ignore
                }
                setActiveView('dashboard');
                window.scrollTo({ top: 0, behavior: 'smooth' });
              }}
              className="font-medium text-[#0c9256] hover:text-[#087443] transition-colors whitespace-nowrap cursor-pointer"
            >
              Dashboard
            </button>
            <button
              type="button"
              onClick={() => {
                setAuthInitialMode('login');
                setActiveView('auth');
                window.scrollTo({ top: 0, behavior: 'smooth' });
              }}
              className="hover:text-[#0c9256] transition-colors whitespace-nowrap cursor-pointer"
            >
              {ZENDO_COPY.authNavLabels.logIn}
            </button>
          </nav>

          {/* Zone 3: Dark Pill CTA Button on Right ("Get Started ->" / "Get a demo ->") */}
          <div className="flex items-center gap-2.5">
            <button
              type="button"
              onClick={() => {
                setAuthInitialMode('signup');
                setActiveView('auth');
                window.scrollTo({ top: 0, behavior: 'smooth' });
              }}
              className="group inline-flex items-center gap-3 px-6 py-3 text-[13.5px] font-normal text-white bg-[#101c19] hover:bg-[#0c9256] rounded-full transition-colors whitespace-nowrap cursor-pointer"
            >
              <span>
                {copyMode === 'metrivello'
                  ? 'Get a demo'
                  : ZENDO_COPY.authNavLabels.getStarted}
              </span>
              <ArrowRight className="w-4 h-4 transition-transform group-hover:translate-x-0.5" />
            </button>
          </div>
        </header>
      </div>

      <main className="flex-1">
        {/* =====================================================================
            01 — HERO (BRIGHT BLUE SKY WITH WHITE CLOUDS + MEADOW HORIZON)
            Exact Match to Screenshot 2026-10-07 073401.png
        ===================================================================== */}
        <section id="product" className="px-2 sm:px-4 pb-12">
          <div className="relative max-w-[1420px] mx-auto rounded-[24px] sm:rounded-[30px] overflow-hidden bg-[#8dc6ec] border border-[#d0e8f5]">
            {/* Full-Bleed Sky, Fluffy White Clouds & Sunlit Green Meadow Horizon Image */}
            <div className="relative w-full min-h-[680px] sm:min-h-[760px] flex flex-col justify-between pt-20 sm:pt-28 px-4 sm:px-8 lg:px-14">
              {!skyImgError ? (
                <img
                  src={skyMeadowHeroImage}
                  alt="Bright blue sky with soft white clouds over a sunlit green meadow"
                  referrerPolicy="no-referrer"
                  onError={() => setSkyImgError(true)}
                  className="pointer-events-none absolute inset-0 w-full h-full object-cover object-top"
                />
              ) : (
                <div
                  aria-hidden="true"
                  className="pointer-events-none absolute inset-0 bg-gradient-to-b from-[#6db3e8] via-[#b8ddf5] to-[#7aa354]"
                />
              )}

              {/* Subtle atmospheric radial light behind center text for crisp legibility */}
              <div
                aria-hidden="true"
                className="pointer-events-none absolute inset-0 bg-[radial-gradient(circle_at_50%_38%,rgba(235,246,255,0.55)_0%,rgba(235,246,255,0.15)_52%,transparent_80%)]"
              />

              {/* HERO COPY BLOCK (Centered in the Sky, Identical to Screenshot) */}
              <div className="relative z-10 max-w-[820px] mx-auto text-center">
                {/* Eyebrow: Small uppercase tracked label */}
                <motion.p
                  initial={{ opacity: 0, y: 8 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ duration: 0.35, ease: [0.16, 1, 0.3, 1] }}
                  className="text-[11px] sm:text-[12px] font-semibold tracking-[0.12em] uppercase text-[#2d4840] mb-5"
                >
                  {heroEyebrow}
                </motion.p>

                {/* Main 2-Line Display Headline in Solid #101c19 */}
                {copyMode === 'zendo' && activeHeadlineIndex === 0 ? (
                  <motion.h1
                    initial={{ opacity: 0, y: 14, filter: 'blur(4px)' }}
                    animate={{ opacity: 1, y: 0, filter: 'blur(0px)' }}
                    transition={{ duration: 0.45, ease: [0.16, 1, 0.3, 1] }}
                    className="text-[42px] sm:text-[64px] lg:text-[74px] font-medium tracking-[-0.038em] text-[#101c19] leading-[1.05]"
                  >
                    Get more done
                    <br />
                    with less effort.
                  </motion.h1>
                ) : copyMode === 'metrivello' ? (
                  <motion.h1
                    initial={{ opacity: 0, y: 14, filter: 'blur(4px)' }}
                    animate={{ opacity: 1, y: 0, filter: 'blur(0px)' }}
                    transition={{ duration: 0.45, ease: [0.16, 1, 0.3, 1] }}
                    className="text-[42px] sm:text-[64px] lg:text-[74px] font-medium tracking-[-0.038em] text-[#101c19] leading-[1.05]"
                  >
                    Know what works.
                    <br />
                    Know what to do next.
                  </motion.h1>
                ) : (
                  <ScrollRevealText
                    key={currentHeroHeadline}
                    as="h1"
                    text={currentHeroHeadline}
                    className="text-[42px] sm:text-[64px] lg:text-[74px] font-medium tracking-[-0.038em] text-[#101c19] leading-[1.05]"
                  />
                )}

                {/* Subheadline: 2 centered lines in #2b3f38 */}
                <motion.p
                  initial={{ opacity: 0, y: 10 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{
                    duration: 0.4,
                    delay: 0.12,
                    ease: [0.16, 1, 0.3, 1],
                  }}
                  className="mt-6 text-[16px] sm:text-[18.5px] font-normal text-[#263832] max-w-[640px] mx-auto leading-[1.55]"
                >
                  {heroSubheadline}
                </motion.p>

                {/* Two Pill Buttons Side-by-Side (Green Left + White Right, Both With Right Arrows) */}
                <motion.div
                  initial={{ opacity: 0, y: 10 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{
                    duration: 0.4,
                    delay: 0.18,
                    ease: [0.16, 1, 0.3, 1],
                  }}
                  className="mt-8 flex flex-wrap items-center justify-center gap-3.5"
                >
                  <button
                    type="button"
                    onClick={() => setActiveView('dashboard')}
                    className="group px-7 py-3.5 text-[14px] font-medium text-white bg-[#0c9256] hover:bg-[#087443] rounded-full transition-colors inline-flex items-center gap-3 whitespace-nowrap cursor-pointer shadow-xs"
                  >
                    <span>{heroPrimaryBtn}</span>
                    <ArrowRight className="w-4 h-4 transition-transform group-hover:translate-x-0.5" />
                  </button>
                  <a
                    href="#how-it-works"
                    className="group px-7 py-3.5 text-[14px] font-medium text-[#101c19] bg-white hover:bg-[#f5f9f7] rounded-full transition-colors inline-flex items-center gap-3 whitespace-nowrap shadow-xs"
                  >
                    <span>{heroSecondaryBtn}</span>
                    <ArrowRight className="w-4 h-4 transition-transform group-hover:translate-x-0.5" />
                  </a>
                </motion.div>

                {/* Supporting Text Directly Below Buttons */}
                <motion.p
                  initial={{ opacity: 0 }}
                  animate={{ opacity: 1 }}
                  transition={{ duration: 0.4, delay: 0.25 }}
                  className="mt-7 text-[13.5px] font-normal text-[#101c19]"
                >
                  {heroSupportingText}
                </motion.p>
              </div>

              {/* ===============================================================
                  ZENDO BROWSER SHOWCASE RISING OVER THE GREEN MEADOW
                  Matches zendo-dashboard-with-logo.png 1:1
              =============================================================== */}
              <motion.div
                initial={{ opacity: 0, y: 28 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{
                  duration: 0.55,
                  delay: 0.24,
                  ease: [0.16, 1, 0.3, 1],
                }}
              >
                <ZendoHeroShowcase
                  userName={userName}
                  tasks={tasks}
                  projects={projects}
                  onOpenWorkspace={(section) => {
                    if (section) setWorkspaceSection(section);
                    setActiveView('dashboard');
                    window.scrollTo({ top: 0, behavior: 'smooth' });
                  }}
                  onQuickAddTask={() => {
                    setWorkspaceSection('tasks');
                    setActiveView('dashboard');
                    window.scrollTo({ top: 0, behavior: 'smooth' });
                  }}
                  onToggleTaskStatus={handleToggleTaskStatus}
                />
              </motion.div>
            </div>
          </div>
        </section>

        {/* =====================================================================
            02 — CONNECTED TOOLS ("A clearer view of the tools you already use.")
        ===================================================================== */}
        <section className="py-14 px-6 lg:px-12 max-w-[1200px] mx-auto">
          <p className="text-center text-sm font-medium text-[#596960] mb-8">
            A clearer view of the tools you already use.
          </p>
          <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-6 gap-3">
            {CONNECTED_TOOLS.map((tool) => (
              <div
                key={tool.name}
                className="px-4 py-3.5 rounded-2xl bg-white border border-[#e1e9e4] flex items-center justify-between gap-2 hover:border-[#a8bdb0] transition-colors"
              >
                <span className="text-xs font-semibold text-[#101c19] truncate">
                  {tool.name}
                </span>
                <span className="text-[11px] text-[#64776a] shrink-0">
                  {tool.category}
                </span>
              </div>
            ))}
          </div>
        </section>

        {/* =====================================================================
            03 — FEATURES (EXACT MINT-BOX SHOWCASE CARDS FROM SCREENSHOT)
        ===================================================================== */}
        <section
          id="features"
          className="py-20 lg:py-28 px-6 lg:px-12 max-w-[1240px] mx-auto"
        >
          <div className="max-w-2xl mb-16">
            <p className="text-xs font-semibold tracking-wider text-[#0c9256] uppercase mb-3">
              BUILT FOR BETTER DECISIONS
            </p>
            <ScrollRevealText
              as="h2"
              text={ZENDO_COPY.featuresSection.headline}
              className="text-3xl sm:text-5xl font-medium tracking-[-0.03em] text-[#101c19] leading-[1.1]"
            />
            <p className="mt-4 text-base text-[#596960] leading-relaxed">
              {ZENDO_COPY.shortBrandDescription}
            </p>
          </div>

          <FeatureShowcaseBoxes
            copyMode={copyMode}
            onInspectFeature={(idx) => {
              const sections: WorkspaceSection[] = [
                'tasks',
                'automations',
                'board',
                'tasks',
                'team',
                'insights',
              ];
              setWorkspaceSection(sections[idx] || 'tasks');
              setActiveView('dashboard');
              window.scrollTo({ top: 0, behavior: 'smooth' });
            }}
          />
        </section>

        {/* =====================================================================
            04 — THE WORKFLOW GAP / BENEFITS SECTION ("Less chaos. More clarity.")
        ===================================================================== */}
        <section id="benefits" className="px-2 sm:px-4 py-8">
          <div className="max-w-[1420px] mx-auto rounded-[30px] metrivello-sky-surface border border-[#d0e8f5] p-6 sm:p-12 lg:p-16">
            <div className="max-w-[1160px] mx-auto grid grid-cols-1 lg:grid-cols-12 gap-12 items-center">
              <div className="lg:col-span-6 space-y-6">
                <p className="text-xs font-semibold tracking-wider text-[#256149] uppercase">
                  THE WORKFLOW SHIFT
                </p>
                <ScrollRevealText
                  as="h2"
                  text={ZENDO_COPY.benefitsSection.headline}
                  className="text-3xl sm:text-5xl font-medium tracking-[-0.03em] text-[#101c19] leading-[1.08]"
                />
                <p className="text-base text-[#3d5950] leading-relaxed">
                  {ZENDO_COPY.benefitsSection.description}
                </p>

                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 pt-2">
                  {ZENDO_COPY.benefitsSection.benefits.map((b) => (
                    <div
                      key={b.title}
                      className="p-3.5 rounded-2xl bg-white/85 border border-[#dce9e2] flex items-center justify-between gap-2"
                    >
                      <span className="text-xs font-semibold text-[#101c19]">
                        {b.title}
                      </span>
                      <span className="text-[11px] font-mono-tabular text-[#0c9256] font-medium shrink-0">
                        {b.stat}
                      </span>
                    </div>
                  ))}
                </div>

                <p className="text-xs font-medium text-[#4a685c] pt-1">
                  {ZENDO_COPY.oneLineTaglines[4]}
                </p>
              </div>

              <div className="lg:col-span-6 space-y-4">
                <div className="grid grid-cols-2 gap-4">
                  <div className="p-4 rounded-2xl bg-white/80 border border-[#dce9e2]">
                    <p className="text-xs text-[#596960]">Scattered Task Apps</p>
                    <p className="text-xl font-semibold font-mono-tabular text-[#101c19] mt-1">
                      5 Tools
                    </p>
                    <p className="text-[11px] text-[#ef7952] mt-1">
                      Disconnected priorities
                    </p>
                  </div>
                  <div className="p-4 rounded-2xl bg-white/80 border border-[#dce9e2]">
                    <p className="text-xs text-[#596960]">Status Meetings</p>
                    <p className="text-xl font-semibold font-mono-tabular text-[#101c19] mt-1">
                      6.4 hrs/wk
                    </p>
                    <p className="text-[11px] text-[#ef7952] mt-1">
                      Lost to manual syncs
                    </p>
                  </div>
                </div>

                <div className="p-6 rounded-[24px] bg-white border border-[#dce9e2] space-y-5 shadow-sm">
                  <div className="flex items-center justify-between">
                    <div>
                      <p className="text-xs text-[#596960]">
                        Unified Zendo Workspace
                      </p>
                      <p className="text-2xl font-semibold font-mono-tabular text-[#101c19] mt-0.5">
                        94% Flow Consistency
                      </p>
                    </div>
                    <span className="text-xs font-medium text-[#0c9256]">
                      Tasks · Projects · Routines
                    </span>
                  </div>

                  <div className="h-28 flex items-end gap-2 pt-2">
                    {[48, 56, 62, 70, 76, 84, 90, 96].map((val, i) => (
                      <div
                        key={i}
                        style={{ height: `${val}%` }}
                        className={`flex-1 rounded-t-lg ${
                          i >= 5 ? 'bg-[#0c9256]' : 'bg-[#a7dfc1]'
                        }`}
                      />
                    ))}
                  </div>

                  <div className="pt-3 border-t border-[#e1e9e4] flex flex-wrap items-center justify-between gap-2 text-xs text-[#596960]">
                    <span>Daily Priorities</span>
                    <span>·</span>
                    <span>Automated Routines</span>
                    <span>·</span>
                    <span className="text-[#087443] font-medium">
                      One Calm System
                    </span>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </section>

        {/* =====================================================================
            05 — HOW IT WORKS ("A better workflow in three simple steps")
        ===================================================================== */}
        <section
          id="how-it-works"
          className="py-20 lg:py-28 px-6 lg:px-12 max-w-[1200px] mx-auto"
        >
          <div className="max-w-2xl mb-16">
            <p className="text-xs font-semibold tracking-wider text-[#0c9256] uppercase mb-3">
              FROM DATA TO DIRECTION
            </p>
            <ScrollRevealText
              as="h2"
              text={ZENDO_COPY.howItWorks.headline}
              className="text-3xl sm:text-5xl font-medium tracking-[-0.03em] text-[#101c19] leading-[1.1]"
            />
            <p className="mt-4 text-base text-[#596960]">
              {ZENDO_COPY.oneLineTaglines[5]}
            </p>
          </div>

          <div className="grid grid-cols-1 lg:grid-cols-3 gap-6 items-start">
            {ZENDO_COPY.howItWorks.steps.map((step, index) => {
              const offsetClass =
                index === 1 ? 'lg:mt-12' : index === 2 ? 'lg:mt-24' : '';
              return (
                <motion.div
                  key={step.number}
                  initial={{ opacity: 0, y: 20 }}
                  whileInView={{ opacity: 1, y: 0 }}
                  viewport={{ once: true }}
                  transition={{
                    duration: 0.45,
                    delay: index * 0.08,
                    ease: [0.16, 1, 0.3, 1],
                  }}
                  className={`${offsetClass} bg-white border border-[#e1e9e4] rounded-[24px] p-7 space-y-6`}
                >
                  <div className="flex items-center justify-between">
                    <span className="text-2xl font-mono-tabular font-semibold text-[#0c9256]">
                      {step.number}
                    </span>
                    <span className="text-xs text-[#64776a]">
                      Step {step.number} of 03
                    </span>
                  </div>

                  <div className="p-4 rounded-2xl bg-[#f5f9f7] border border-[#e1e9e4] space-y-2">
                    <p className="text-xs font-semibold text-[#101c19]">
                      {step.cleanTitle}
                    </p>
                    <p className="text-xs text-[#596960] leading-relaxed">
                      {step.detail}
                    </p>
                  </div>

                  <div className="space-y-2">
                    <h3 className="text-xl font-semibold text-[#101c19]">
                      {step.label}
                    </h3>
                    <p className="text-sm text-[#596960] leading-relaxed">
                      {step.description}
                    </p>
                  </div>
                </motion.div>
              );
            })}
          </div>

          <p className="mt-12 text-center text-sm font-medium text-[#4a685c]">
            {ZENDO_COPY.oneLineTaglines[2]}
          </p>
        </section>

        {/* =====================================================================
            06 — WHO IT IS FOR + 07 — CUSTOMER STORIES (SOCIAL PROOF SECTION)
        ===================================================================== */}
        <section
          id="stories"
          className="py-20 lg:py-28 px-6 lg:px-12 max-w-[1200px] mx-auto space-y-24"
        >
          <div>
            <div className="max-w-2xl mb-14">
              <p className="text-xs font-semibold tracking-wider text-[#0c9256] uppercase mb-3">
                ONE VIEW, DIFFERENT PERSPECTIVES
              </p>
              <ScrollRevealText
                as="h2"
                text={ZENDO_COPY.socialProofSection.headline}
                className="text-3xl sm:text-5xl font-medium tracking-[-0.03em] text-[#101c19] leading-[1.1]"
              />
              <p className="mt-4 text-base text-[#596960] leading-relaxed">
                {ZENDO_COPY.socialProofSection.description}
              </p>
            </div>

            <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-center">
              <div className="lg:col-span-5">
                <div className="relative rounded-[24px] overflow-hidden border border-[#e1e9e4] bg-[#101c19] aspect-[3/4]">
                  {!portraitImgError ? (
                    <img
                      src={editorialPortrait}
                      alt="Founder working with clarity in Zendo"
                      referrerPolicy="no-referrer"
                      onError={() => setPortraitImgError(true)}
                      className="w-full h-full object-cover"
                    />
                  ) : (
                    <div className="w-full h-full bg-gradient-to-br from-[#123b29] to-[#0b1713]" />
                  )}
                  <div className="absolute inset-0 bg-gradient-to-t from-black/75 via-black/20 to-transparent" />
                  <div className="absolute bottom-6 left-6 right-6 text-white">
                    <p className="text-xs text-white/80">
                      {ZENDO_COPY.oneLineTaglines[1]}
                    </p>
                    <p className="text-base font-semibold mt-0.5">
                      {ZENDO_COPY.oneLineTaglines[5]}
                    </p>
                  </div>
                </div>
              </div>

              <div className="lg:col-span-7 divide-y divide-[#e1e9e4] border-y border-[#e1e9e4]">
                {[
                  {
                    num: '01',
                    role: 'Founders & Business Owners',
                    desc: 'Keep company priorities, quarterly goals, and daily execution in one clear view without tool sprawl.',
                  },
                  {
                    num: '02',
                    role: 'Team Leads & Managers',
                    desc: 'Share updates, assign tasks, and keep everyone aligned without endless status meetings.',
                  },
                  {
                    num: '03',
                    role: 'Independent Professionals',
                    desc: 'Replace scattered notes and complex boards with a calm daily queue built around deep focus.',
                  },
                  {
                    num: '04',
                    role: 'Product & Operations Teams',
                    desc: 'Automate recurring handoffs and track upcoming deadlines with zero overdue surprises.',
                  },
                ].map((item) => (
                  <div
                    key={item.num}
                    className="py-6 flex flex-col sm:flex-row sm:items-baseline justify-between gap-4"
                  >
                    <div className="flex items-baseline gap-4">
                      <span className="text-xs font-mono-tabular font-semibold text-[#0c9256]">
                        {item.num}
                      </span>
                      <h3 className="text-lg font-semibold text-[#101c19]">
                        {item.role}
                      </h3>
                    </div>
                    <p className="text-sm text-[#596960] max-w-md leading-relaxed">
                      {item.desc}
                    </p>
                  </div>
                ))}
              </div>
            </div>
          </div>

          {/* 07: Customer Stories & Two-Column Scrolling Reviews */}
          <ScrollingReviews
            onSelectReview={(rev) =>
              showToast(`Highlighted ${rev.author}’s review (${rev.company})`)
            }
          />
        </section>

        {/* =====================================================================
            08 — PRICING ("Start simple. Grow when you’re ready.")
        ===================================================================== */}
        <section
          id="pricing"
          className="py-20 lg:py-28 px-6 lg:px-12 max-w-[1200px] mx-auto"
        >
          <div className="flex flex-col md:flex-row md:items-end justify-between gap-6 mb-14">
            <div className="max-w-xl">
              <p className="text-xs font-semibold tracking-wider text-[#0c9256] uppercase mb-3">
                SIMPLE PLANS, CLEAR SCOPE
              </p>
              <ScrollRevealText
                as="h2"
                text={ZENDO_COPY.pricingSection.headline}
                className="text-3xl sm:text-5xl font-medium tracking-[-0.03em] text-[#101c19] leading-[1.1]"
              />
              <p className="mt-3 text-base text-[#596960]">
                {ZENDO_COPY.pricingSection.subheadline}
              </p>
            </div>

            <div className="inline-flex items-center gap-1.5 p-1.5 bg-white border border-[#e1e9e4] rounded-full self-start md:self-auto">
              <button
                type="button"
                onClick={() => setBillingCycle('monthly')}
                className={`px-4 py-2 text-xs font-medium rounded-full transition-colors whitespace-nowrap cursor-pointer ${
                  billingCycle === 'monthly'
                    ? 'bg-[#101c19] text-white'
                    : 'text-[#596960] hover:text-[#101c19]'
                }`}
              >
                Monthly
              </button>
              <button
                type="button"
                onClick={() => setBillingCycle('yearly')}
                className={`px-4 py-2 text-xs font-medium rounded-full transition-colors inline-flex items-center gap-2 whitespace-nowrap cursor-pointer ${
                  billingCycle === 'yearly'
                    ? 'bg-[#101c19] text-white'
                    : 'text-[#596960] hover:text-[#101c19]'
                }`}
              >
                <span>Yearly</span>
                <span className="text-[11px] font-semibold text-[#ef7952]">
                  Save 25%
                </span>
              </button>
            </div>
          </div>

          <div className="grid grid-cols-1 lg:grid-cols-3 gap-6 items-stretch">
            {ZENDO_COPY.pricingSection.tiers.map((tier) => {
              const price =
                billingCycle === 'yearly' ? tier.yearlyPrice : tier.monthlyPrice;
              const isFeatured = tier.highlighted;

              return (
                <div
                  key={tier.name}
                  className={`rounded-[28px] p-8 flex flex-col justify-between gap-8 border ${
                    isFeatured
                      ? 'bg-[#101c19] text-white border-[#123b29] shadow-xl'
                      : 'bg-white text-[#101c19] border-[#e1e9e4]'
                  }`}
                >
                  <div className="space-y-6">
                    <div className="space-y-2">
                      <p
                        className={`text-[11px] font-semibold tracking-wider uppercase ${
                          isFeatured ? 'text-[#b8f78f]' : 'text-[#0c9256]'
                        }`}
                      >
                        {tier.name === 'Free'
                          ? 'YOUR STARTING POINT'
                          : tier.name === 'Pro'
                          ? 'RECOMMENDED FOR GROWTH'
                          : 'BUILT FOR TEAMS'}
                      </p>
                      <h3 className="text-2xl font-semibold">{tier.name}</h3>
                      <p
                        className={`text-sm leading-relaxed ${
                          isFeatured ? 'text-white/75' : 'text-[#596960]'
                        }`}
                      >
                        {tier.description}
                      </p>
                    </div>

                    <div
                      className={`pt-5 border-t flex items-baseline gap-2 ${
                        isFeatured ? 'border-white/15' : 'border-[#e1e9e4]'
                      }`}
                    >
                      <span className="text-4xl font-semibold font-mono-tabular">
                        ${price}
                      </span>
                      <span
                        className={`text-xs ${
                          isFeatured ? 'text-white/70' : 'text-[#596960]'
                        }`}
                      >
                        {tier.name === 'Free'
                          ? 'free forever'
                          : billingCycle === 'yearly'
                          ? tier.cadenceLabel
                          : 'per month, billed monthly'}
                      </span>
                    </div>

                    <ul className="space-y-3 pt-2">
                      {tier.specs.map((spec) => (
                        <li
                          key={spec.label}
                          className="flex items-center justify-between gap-2 text-xs"
                        >
                          <div className="flex items-center gap-2">
                            <Check
                              className={`w-4 h-4 shrink-0 ${
                                isFeatured ? 'text-[#b8f78f]' : 'text-[#0c9256]'
                              }`}
                            />
                            <span
                              className={
                                isFeatured ? 'text-white/80' : 'text-[#596960]'
                              }
                            >
                              {spec.label}
                            </span>
                          </div>
                          <span className="font-medium">{spec.value}</span>
                        </li>
                      ))}
                    </ul>
                  </div>

                  <button
                    type="button"
                    onClick={() => {
                      setAuthInitialMode('signup');
                      setActiveView('auth');
                      window.scrollTo({ top: 0, behavior: 'smooth' });
                    }}
                    className={`w-full py-3.5 px-5 rounded-full text-xs font-medium transition-colors whitespace-nowrap cursor-pointer ${
                      isFeatured
                        ? 'bg-[#0c9256] hover:bg-[#18a165] text-white'
                        : 'bg-[#f0f7f3] hover:bg-[#e8f7ee] text-[#101c19] border border-[#dce9e2]'
                    }`}
                  >
                    {ZENDO_COPY.pricingSection.ctaButton}
                  </button>
                </div>
              );
            })}
          </div>
        </section>

        {/* =====================================================================
            09 & 10 — EMBEDDED GOOGLE SIGN IN (zendo.ai)
        ===================================================================== */}
        <section
          id="resources"
          className="py-20 lg:py-28 px-6 lg:px-12 max-w-[1200px] mx-auto"
        >
          <div className="max-w-md mx-auto">
            <div className="bg-white border border-[#e1e9e4] rounded-[28px] p-8 shadow-xs">
              <div className="mb-6">
                <div className="flex items-center gap-2 text-xs text-[#596960] mb-2">
                  <ZendoLogo className="w-5 h-5 shrink-0" color="#101c19" />
                  <span className="font-semibold text-[#101c19]">
                    zendo.ai
                  </span>
                  <span aria-hidden="true">·</span>
                  <span>Firebase Google Auth</span>
                </div>
                <h3 className="text-2xl font-semibold tracking-tight text-[#101c19]">
                  Sign in to zendo.ai
                </h3>
                <p className="mt-1.5 text-sm text-[#596960]">
                  Continue with your Google account to create AI proposals, message clients, and manage tasks in zendo.ai.
                </p>
              </div>

              <div className="space-y-4">
                <button
                  type="button"
                  onClick={handleInlineGoogleLogin}
                  disabled={inlineAuthLoading}
                  className="group w-full h-12 px-5 py-2.5 bg-[#0c9256] hover:bg-[#087443] text-white text-sm font-medium rounded-full transition-colors flex items-center justify-center gap-3 whitespace-nowrap cursor-pointer"
                >
                  <span className="w-6 h-6 rounded-full bg-white flex items-center justify-center shrink-0">
                    <svg className="w-3.5 h-3.5 shrink-0" viewBox="0 0 24 24">
                      <path
                        fill="#4285F4"
                        d="M23.49 12.27c0-.79-.07-1.54-.19-2.27H12v4.51h6.47c-.29 1.48-1.14 2.73-2.4 3.58v3h3.86c2.26-2.09 3.56-5.17 3.56-8.82Z"
                      />
                      <path
                        fill="#34A853"
                        d="M12 24c3.24 0 5.95-1.08 7.93-2.91l-3.86-3c-1.08.72-2.45 1.16-4.07 1.16-3.13 0-5.78-2.11-6.73-4.96H1.29v3.09C3.26 21.3 7.31 24 12 24Z"
                      />
                      <path
                        fill="#FBBC05"
                        d="M5.27 14.29c-.25-.72-.38-1.49-.38-2.29s.13-1.57.38-2.29V6.62H1.29C.47 8.24 0 10.06 0 12s.47 3.76 1.29 5.38l3.98-3.09Z"
                      />
                      <path
                        fill="#EA4335"
                        d="M12 4.75c1.77 0 3.35.61 4.6 1.8l3.42-3.42C17.95 1.19 15.24 0 12 0 7.31 0 3.26 2.7 1.29 6.62l3.98 3.09c.95-2.85 3.6-4.96 6.73-4.96Z"
                      />
                    </svg>
                  </span>
                  <span>
                    {inlineAuthLoading
                      ? 'Signing in with Google...'
                      : 'Continue with Google to zendo.ai'}
                  </span>
                  <ArrowRight className="w-4 h-4 transition-transform group-hover:translate-x-0.5" />
                </button>

                {inlineAuthError && (
                  <p className="text-xs text-[#9a342d] font-medium" role="alert">
                    {inlineAuthError}
                  </p>
                )}
              </div>

              <p className="mt-5 pt-4 border-t border-[#e1e9e4] text-xs text-[#596960] text-center">
                {ZENDO_COPY.authCopy.signupText}
              </p>
            </div>
          </div>
        </section>

        {/* =====================================================================
            11 — FREQUENTLY ASKED QUESTIONS (WITH METRIVELLO ORBIT HALF-RINGS)
        ===================================================================== */}
        <section
          id="faq"
          className="relative py-20 lg:py-28 px-6 lg:px-12 overflow-hidden border-t border-[#e1e9e4]"
        >
          <div
            aria-hidden="true"
            className="pointer-events-none absolute -top-40 left-1/2 -translate-x-1/2 w-[900px] h-[900px] rounded-full border border-[#64776a]/15"
          />
          <div
            aria-hidden="true"
            className="pointer-events-none absolute -top-20 left-1/2 -translate-x-1/2 w-[640px] h-[640px] rounded-full border border-[#64776a]/15"
          />

          <div className="relative max-w-[1200px] mx-auto grid grid-cols-1 lg:grid-cols-12 gap-12">
            <div className="lg:col-span-5 space-y-4">
              <p className="text-xs font-semibold tracking-wider text-[#0c9256] uppercase">
                A FEW THINGS TO KNOW
              </p>
              <h2 className="text-3xl sm:text-4xl font-medium tracking-[-0.03em] text-[#101c19] leading-[1.1]">
                Clear answers, before you get started.
              </h2>
              <p className="text-sm text-[#596960] leading-relaxed">
                More context on Zendo Lite, your daily workflow, and how your team
                stays in control.
              </p>
            </div>

            <div className="lg:col-span-7 space-y-3">
              {FAQ_ITEMS.map((item, idx) => {
                const isOpen = openFaqIndex === idx;
                return (
                  <div
                    key={item.q}
                    className="bg-white border border-[#e1e9e4] rounded-2xl overflow-hidden"
                  >
                    <button
                      type="button"
                      onClick={() => setOpenFaqIndex(isOpen ? null : idx)}
                      className="w-full px-6 py-4 text-left flex items-center justify-between gap-4 cursor-pointer"
                    >
                      <span className="text-sm sm:text-base font-medium text-[#101c19]">
                        {item.q}
                      </span>
                      <span
                        className={`w-7 h-7 rounded-full bg-[#f0f7f3] flex items-center justify-center text-[#101c19] transition-transform duration-200 shrink-0 ${
                          isOpen ? 'rotate-45' : ''
                        }`}
                      >
                        <Plus className="w-4 h-4" />
                      </span>
                    </button>
                    <AnimatePresence initial={false}>
                      {isOpen && (
                        <motion.div
                          initial={{ opacity: 0 }}
                          animate={{ opacity: 1 }}
                          exit={{ opacity: 0 }}
                          transition={{ duration: 0.18 }}
                          className="px-6 pb-5 text-sm text-[#596960] leading-relaxed border-t border-[#e1e9e4]/60 pt-3"
                        >
                          {item.a}
                        </motion.div>
                      )}
                    </AnimatePresence>
                  </div>
                );
              })}
            </div>
          </div>
        </section>
      </main>

      {/* =====================================================================
          FLOATING BOTTOM-RIGHT PILLS (EXACT MATCH TO SCREENSHOT CORNER PILLS)
          Allows instant toggling between Zendo Copy & Metrivello Original Copy
          or opening the Copy Kit Drawer!
      ===================================================================== */}
      <div className="fixed bottom-4 right-4 z-30 flex flex-col items-end gap-2">
        <button
          type="button"
          onClick={() => {
            setActiveView('onboarding');
            window.scrollTo({ top: 0, behavior: 'smooth' });
          }}
          className="px-4 py-2 bg-white hover:bg-[#f5f9f7] text-[#101c19] text-xs font-medium rounded-xl shadow-md border border-[#e1e9e4] flex items-center gap-2 cursor-pointer whitespace-nowrap"
        >
          <span>Open Proposal Setup</span>
          <span className="text-[#0c9256] font-semibold">2-Step Onboarding</span>
        </button>
        <button
          type="button"
          onClick={() => {
            setAuthInitialMode('login');
            setActiveView('auth');
            window.scrollTo({ top: 0, behavior: 'smooth' });
          }}
          className="px-4 py-2 bg-white hover:bg-[#f5f9f7] text-[#101c19] text-xs font-medium rounded-xl shadow-md border border-[#e1e9e4] flex items-center gap-2 cursor-pointer whitespace-nowrap"
        >
          <span>Open Auth Page</span>
          <span className="text-[#0c9256] font-semibold">Log In / Sign Up</span>
        </button>
        <button
          type="button"
          onClick={() => setCopyKitOpen(true)}
          className="px-4 py-2 bg-white hover:bg-[#f5f9f7] text-[#101c19] text-xs font-medium rounded-xl shadow-md border border-[#e1e9e4] flex items-center gap-2 cursor-pointer whitespace-nowrap"
        >
          <span>Zendo Copy Kit</span>
          <span className="text-[#7c8a81]">All Sections</span>
        </button>
        <button
          type="button"
          onClick={() =>
            setCopyMode((prev) => (prev === 'zendo' ? 'metrivello' : 'zendo'))
          }
          className="px-4 py-2 bg-white hover:bg-[#f5f9f7] text-[#101c19] text-xs font-medium rounded-xl shadow-md border border-[#e1e9e4] flex items-center gap-2 cursor-pointer whitespace-nowrap"
        >
          <span className="w-2 h-2 rounded-full bg-[#0c9256]" />
          <span>
            Mode: {copyMode === 'zendo' ? 'Zendo Lite Copy' : 'Metrivello Copy'}
          </span>
        </button>
      </div>

      {/* =====================================================================
          FOOTER + FINAL CALL-TO-ACTION ("Make your work feel lighter.")
      ===================================================================== */}
      <footer className="bg-[#0b1713] text-white pt-20 pb-12 px-6 lg:px-12 relative overflow-hidden">
        <div className="max-w-[1200px] mx-auto space-y-16 relative z-10">
          <div className="flex flex-col lg:flex-row lg:items-end justify-between gap-8">
            <div className="max-w-xl space-y-4">
              <p className="text-xs font-semibold tracking-wider text-[#b8f78f] uppercase">
                {ZENDO_COPY.oneLineTaglines[5]}
              </p>
              <ScrollRevealText
                as="h2"
                text={ZENDO_COPY.ctaSection.headline}
                className="text-4xl sm:text-5xl lg:text-[54px] font-medium tracking-[-0.03em] text-white leading-[1.08]"
              />
              <p className="text-base sm:text-lg text-[#a8bdb0] leading-relaxed">
                {ZENDO_COPY.ctaSection.subheadline}
              </p>
            </div>

            <div className="flex flex-wrap items-center gap-3.5">
              <button
                type="button"
                onClick={() => {
                  setAuthInitialMode('signup');
                  setActiveView('auth');
                  window.scrollTo({ top: 0, behavior: 'smooth' });
                }}
                className="group px-7 py-4 text-sm font-medium text-white bg-[#0c9256] hover:bg-[#18a165] rounded-full transition-colors inline-flex items-center gap-2.5 whitespace-nowrap cursor-pointer"
              >
                <span>{ZENDO_COPY.ctaSection.button}</span>
                <ArrowRight className="w-4 h-4 transition-transform group-hover:translate-x-0.5" />
              </button>
              <button
                type="button"
                onClick={() => setActiveView('dashboard')}
                className="px-6 py-4 text-sm font-medium text-white/90 hover:text-white border border-[#64776a]/40 hover:border-white/50 rounded-full transition-colors whitespace-nowrap cursor-pointer"
              >
                Open Live Dashboard
              </button>
            </div>
          </div>

          <div className="h-px w-full bg-[#64776a]/25" />

          <div className="grid grid-cols-2 sm:grid-cols-4 lg:grid-cols-5 gap-8 text-xs">
            <div className="col-span-2 lg:col-span-2 space-y-3 pr-6">
              <div className="inline-flex items-center gap-2.5">
                <ZendoLogo className="w-7 h-7 shrink-0" color="#ffffff" />
                <span className="text-lg font-bold text-white">
                  {ZENDO_COPY.brandName}
                </span>
              </div>
              <p className="text-[#8a9991] leading-relaxed max-w-sm">
                {ZENDO_COPY.shortBrandDescription}
              </p>
            </div>

            <div className="space-y-2.5">
              <p className="font-semibold text-[#64776a] uppercase tracking-wider">
                PRODUCT
              </p>
              <ul className="space-y-2 text-[#d0eedd]/80">
                {ZENDO_COPY.navigationLabels.map((nav) => (
                  <li key={nav.label}>
                    <a
                      href={nav.href}
                      className="hover:text-white transition-colors"
                    >
                      {nav.label}
                    </a>
                  </li>
                ))}
              </ul>
            </div>

            <div className="space-y-2.5">
              <p className="font-semibold text-[#64776a] uppercase tracking-wider">
                WORKSPACE
              </p>
              <ul className="space-y-2 text-[#d0eedd]/80">
                <li>
                  <button
                    type="button"
                    onClick={() => setActiveView('dashboard')}
                    className="hover:text-white transition-colors cursor-pointer"
                  >
                    Today’s Tasks
                  </button>
                </li>
                <li>
                  <button
                    type="button"
                    onClick={() => setActiveView('dashboard')}
                    className="hover:text-white transition-colors cursor-pointer"
                  >
                    Productivity Overview
                  </button>
                </li>
                <li>
                  <button
                    type="button"
                    onClick={() => {
                      setAuthInitialMode('login');
                      setActiveView('auth');
                      window.scrollTo({ top: 0, behavior: 'smooth' });
                    }}
                    className="hover:text-white transition-colors cursor-pointer"
                  >
                    Log In
                  </button>
                </li>
                <li>
                  <button
                    type="button"
                    onClick={() => setCopyKitOpen(true)}
                    className="text-[#b8f78f] hover:underline cursor-pointer"
                  >
                    Complete Copy Kit
                  </button>
                </li>
              </ul>
            </div>

            <div className="space-y-2.5">
              <p className="font-semibold text-[#64776a] uppercase tracking-wider">
                TAGLINES
              </p>
              <ul className="space-y-2 text-[#8a9991]">
                {ZENDO_COPY.oneLineTaglines.slice(0, 4).map((t) => (
                  <li key={t} className="truncate">
                    {t}
                  </li>
                ))}
              </ul>
            </div>
          </div>

          <div className="h-px w-full bg-[#64776a]/25" />

          <div className="flex flex-col sm:flex-row items-center justify-between gap-4 text-xs text-[#8a9991]">
            <span>© {new Date().getFullYear()} Zendo Lite. All rights reserved.</span>
            <span>{ZENDO_COPY.oneLineTaglines[0]}</span>
          </div>
        </div>
      </footer>

      {commandPaletteNode}

      <AuthModal
        isOpen={authModalOpen}
        initialMode={authInitialMode}
        onClose={() => setAuthModalOpen(false)}
        onSuccess={(name, email) => {
          setUserName(name || 'Findify Ai');
          if (email) setUserEmail(email);
          setAuthModalOpen(false);
          try {
            window.history.pushState({}, '', '/onboarding');
          } catch {
            // ignore
          }
          setActiveView('onboarding');
          showToast(`Welcome ${name || 'Findify Ai'}! Please share a few details about your business.`);
          window.scrollTo({ top: 0, behavior: 'smooth' });
        }}
      />

      <CopyKitDrawer
        isOpen={copyKitOpen}
        onClose={() => setCopyKitOpen(false)}
        activeHeadline={currentHeroHeadline}
        onApplyHeadline={(hl) => {
          const idx = ZENDO_COPY.hero.alternativeHeadlines.indexOf(hl);
          if (idx !== -1) setActiveHeadlineIndex(idx);
          setCopyKitOpen(false);
        }}
      />

      {toastMessage && (
        <div className="fixed bottom-5 left-5 z-50 px-4 py-3 rounded-2xl bg-[#101c19] text-white text-xs font-medium shadow-xl border border-[#256149] flex items-center gap-2.5">
          <span className="w-2 h-2 rounded-full bg-[#47c28b]" />
          <span>{toastMessage}</span>
        </div>
      )}
    </div>
  );
}
